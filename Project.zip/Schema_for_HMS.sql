--Creating Patients Table
--Table # 01
Create Table Patientss(
Patient_id INTEGER
 CONSTRAINT patient_PMkey PRIMARY KEY,
 Patient_name VARCHAR2(38),
 Patient_Phone Integer,
 Patient_Address VARCHAR(38),
 Patient_Age Integer
);
--Drop Table Patients;
--Insert Operation
Insert Into Patientss(patient_id,patient_name,patient_phone,patient_address,patient_age) 
Values(2,'Hadi','03155319242','Nawabshah2','23');

--Select *From  Patientss;



--(*^*)****************************************************************************(*^*)--
--Creating Diseases Table
--Table # 02
--Aleardy Added
Create Table Diseasess(
Disease_ID Integer 
Constraint Disease_PMKey Primary Key,
Disease_name VARCHAR2(38)
);
INSERT INTO DISEASESs(disease_id,disease_name)
VALUES(2,'Skin');
Drop TAble Diseasess;











--(*^*)****************************************************************************(*^*)--
--Table # 03
Create Table Doctorss(
Doctor_id INTEGER
 CONSTRAINT Doctor_PMkey PRIMARY KEY,
 Doctor_name VARCHAR2(38),
 Doctor_Phone Integer,
 Doctor_Address VARCHAR(38),
 Doctor_Age Integer
);
ALTER TABLE Doctorss
ADD CONSTRAINT Spec_dis_fk
Spec_Dis REFERENCES Diseases(Disease_id);
Desc diseases;
Select *From Diseases;
Drop Table Doctorss;
Select *From Doctorss;
Insert Into Doctorss(Doctor_id,modified_by,Doctor_name,Doctor_phone,Doctor_address,Doctor_age) 
Values(1,2,'Ali','03185319249','Mardan','25');









--(*^*)****************************************************************************(*^*)--
--Table # 04
Create Table Reports(
Report_id INTEGER
 CONSTRAINT Report_PMkey PRIMARY KEY,
 Report_Description VARCHAR2(38)
 --Doctor_Phone Integer,
 --Doctor_Address VARCHAR(38),
 --Doctor_Age Integer
);
Alter TAble Reports
ADD Constraint FK_PId
Patient_Id REFERENCES patientss(patient_id);
INSERT INTO reports(report_id,report_description,patient_id)
VALUES(2,'THis is 2nd Report of Patient',2);
Select *from reports;









--(*^*)****************************************************************************(*^*)--
--Table # 05
Create Table Pat_Dis_Norm(
No_of_Time INTEGER
-- CONSTRAINT Report_PMkey PRIMARY KEY --,
 --Doctor_name VARCHAR2(38),
 --Doctor_Phone Integer,
 --Doctor_Address VARCHAR(38),
 --Doctor_Age Integer
);
Drop Table pat_dis_norm;
SELECT * FROM pat_dis_norm ;
ALTER TABLE pat_dis_norm
Add Constraint FK_Pid
Patient_Id REFERENCES patientss(patient_id);
ALTER TABLE pat_dis_norm
Add Constraint FK_DisID
Disease_Id REFERENCES Diseases(disease_id);
Select *From pat_dis_norm;

INSert into pat_dis_norm(no_of_time,patient_id,disease_id)
Values(1,2,1);
--(*^*)****************************************************************************(*^*)--
--Table # 06
Create Table Appointments(
No_of_Appointments Integer
--Foreign Key Patients

--Foreign Key Doctors

);
--Foreign Key Doctors
ALTER TABLE Appointments
ADD CONSTRAINT Doc_Fk
Doctor_ID REFERENCES Doctorss(Doctor_id);
--Foreign Key Patients
ALTER TABLE Appointments
ADD CONSTRAINT Pat_Fk
Patient_ID REFERENCES Patientss(Patient_id);
SELECT * FROM Appointments;
--Inserting in Appointments
INSERT INTO APPOINTMENTS(no_of_appointments,patient_id,doctor_id)
VALUES(1,2,2);
Desc appointments;
Drop Table Apointments;


--All TAbles
SELECT * FROM patientss ;
SELECT * FROM doctorss ;
SELECT * FROM diseases ;
SELECT * FROM appointments ;
SELECT * FROM pat_dis_norm ;
Select *from reports ;
commit;
--Operations
SELECT * FROM patientss ;
SELECT * FROM doctorss ;
SELECT * FROM appointments ;
Select *from reports ;
--Book Appointment
Insert INto appointments(no_of_appointments,patient_id,doctor_id)
Values(2,1,1);
--View Appointments
SELECT patient_name,Doctor_name,no_of_appointments 
FROM patientss p,doctorss d,appointments ap
Where p.patient_id=ap.patient_id
and d.doctor_id=ap.doctor_id;
--View Report
Select patient_name,report_description From Patientss p,reports r
Where p.patient_id=r.patient_id;
Select * From Reports;
Alter Table Reports
Add Constraint FK_Did
Doctor_ID References Doctorss(doctor_id);
