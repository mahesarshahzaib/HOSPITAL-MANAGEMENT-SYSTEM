/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patient_reg_connect_ret_pat_doc;

/**
 *
 * @author ehtes
 */
public class Doctorss {
private String Doctor_id;    
private String Doctor_name;    
private String Doctor_phone;
private String Doctor_address;

    public Doctorss(String Doctor_id, String Doctor_name, String Doctor_phone, String Doctor_address) {
        this.Doctor_id = Doctor_id;
        this.Doctor_name = Doctor_name;
        this.Doctor_phone = Doctor_phone;
        this.Doctor_address = Doctor_address;
    }

    public String getDoctor_address() {
        return Doctor_address;
    }

    public void setDoctor_address(String Doctor_address) {
        this.Doctor_address = Doctor_address;
    }

    public String getDoctor_id() {
        return Doctor_id;
    }

    public void setDoctor_id(String Doctor_id) {
        this.Doctor_id = Doctor_id;
    }

    public String getDoctor_name() {
        return Doctor_name;
    }

    public void setDoctor_name(String Doctor_name) {
        this.Doctor_name = Doctor_name;
    }

    public String getDoctor_phone() {
        return Doctor_phone;
    }

    public void setDoctor_phone(String Doctor_phone) {
        this.Doctor_phone = Doctor_phone;
    }



}