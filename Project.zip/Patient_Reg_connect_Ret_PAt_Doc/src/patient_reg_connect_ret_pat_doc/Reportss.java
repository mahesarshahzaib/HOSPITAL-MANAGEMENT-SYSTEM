/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patient_reg_connect_ret_pat_doc;

/**
 *
 * @author ehtes
 */
public class Reportss {
//report_id,report_description,patient_id,doctor_id)
String report_id;
String report_description;
String patient_id;
String doctor_id;

    public Reportss(String report_id, String report_description, String patient_id, String doctor_id) {
        this.report_id = report_id;
        this.report_description = report_description;
        this.patient_id = patient_id;
        this.doctor_id = doctor_id;
    }

    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public String getReport_description() {
        return report_description;
    }

    public void setReport_description(String report_description) {
        this.report_description = report_description;
    }

    public String getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(String patient_id) {
        this.patient_id = patient_id;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(String doctor_id) {
        this.doctor_id = doctor_id;
    }


}
