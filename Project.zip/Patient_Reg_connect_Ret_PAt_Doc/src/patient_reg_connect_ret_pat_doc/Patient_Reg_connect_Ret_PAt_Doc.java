/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patient_reg_connect_ret_pat_doc;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Peggy Fisher
 */
public class Patient_Reg_connect_Ret_PAt_Doc extends Application {
//static int patient_id=9;
    int patientid=4;
    int dis_id=1;
    Hyperlink options[] = new Hyperlink[] {
        new Hyperlink("Patient Registration"),
        new Hyperlink("Doctor Registration"),
        new Hyperlink("Appointments"),
        new Hyperlink("View All Doctors"),
        new Hyperlink("View All Patients"),
        new Hyperlink("Generate Patient Report"),
        new Hyperlink("View all Reports"),
    };
 
    @Override
    public void start(Stage primaryStage) {

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(5);
        grid.setPadding(new Insets(0, 10, 0, 10));
        grid.setVisible(true);
    
//    docgrid.setGridLinesVisible(true);
    
// Category in column 2, row 1
    Text operations = new Text("Operations:");
    operations.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    grid.add(operations, 1, 0); 

    // Title in column 3, row 1
    Text chartTitle = new Text("Patient Registration");   
    chartTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    grid.add(chartTitle, 2, 0);

    
    /*ImageView imageHouse = new ImageView(
       new Image(LayoutExample.class.getResourceAsStream("home.gif")));
    docgrid.add(imageHouse, 0, 0, 1, 2); 
*/
    
    
    //Labels
    Label pID = new Label("Patient ID");
    Label pName = new Label("Patient Name");
    Label pCont = new Label("Contact No");
    Label pAge = new Label("Patient Age");
    grid.add(pID,0,2);
    grid.add(pName,0,5);
    grid.add(pCont,0,8);
    grid.add(pAge,0,11);
    
    Label pMaritalstatus = new Label("Gender");
    Label pAddress = new Label("Patient Address");
    Label Disease = new Label("Select Disease");
    Label Doctor = new Label("Select Doctor");
    
    
    grid.add(pMaritalstatus,2,2);
    grid.add(pAddress,2,5);
    grid.add(Disease,2,8);
    grid.add(Doctor,2,11);
//TextField 
//String Patid=Integer.toString(++patientid);
try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select Patient_id from Patientss";
            ResultSet rs=stmt.executeQuery(sqlquery);
//             stmt.close();
             while(rs.next())
             {
                 patientid=rs.getInt("Patient_id");
                 System.out.println(patientid);
             }
             ++patientid;
             System.out.println("Out"+patientid);
//            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
System.out.println(" Saffa Out"+patientid);
//String Patid=Integer.toString(patientid);
    TextField Pid = new TextField("");
    Pid.setText(Integer.toString(patientid));
    Pid.setEditable(false);
    TextField Pname = new TextField("");
    TextField Pcont = new TextField("");
    TextField Page = new TextField("");
    grid.add(Pid,0,3);
    grid.add(Pname,0,6);
    grid.add(Pcont,0,9);
    grid.add(Page,0,12);
    
    ComboBox MStauts = new ComboBox();
    MStauts.getItems().addAll(
            "Sigle",
            "Married" 
        );
        
    TextField address=new TextField("");
    
    
        
    ComboBox SelectDisease = new ComboBox();
List<String> list = new ArrayList<String>();

int i=0;
//Retrieving Diseases.;
                try{
    
            Class.forName("oracle.jdbc.driver.OracleDriver");
                    System.out.println("Here 1st");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
                    System.out.println("Here 2");
            Statement stmt=con.createStatement();
            //System.out.println("PID = "+Integer.parseInt(DidAppointment.getText()));              
            System.out.println("Added row to customers table");  
//            Patients p=new Patients(Integer.parseInt(DidAppointment.getText()), Dname.getText(), Integer.parseInt(Dcont.getText()), Daddress.getText(), Integer.parseInt(Page.getText()));
//            String sql=("Insert Into Patients (patient_id,patient_name,phone,Daddress,patient_age) Values("+patient_id+",'"+patient_name+"',"+phone+",'"+patient_address+"',"+patient_age+")");     
                    
            String sql="Select Disease_name From diseases";     
                           System.out.println("Selected");  
            ResultSet rs=stmt.executeQuery(sql);
                           System.out.println("Exception Here");  
            while(rs.next()){
                list.add(rs.getString("disease_name").toString());
//        String val=rs.getString("Disease_name").toString();
//Dis
//             SelectDisease.getItem().add(dis);
            ++i;
            }
                stmt.executeQuery(sql);
        stmt.close();
        con.close();
            }
            catch(Exception exce){
                System.out.println("in Exception");
            System.out.println(exce.getMessage());
        }
     ObservableList<String> observableList = FXCollections.observableList(list);
//    for(int j=0;j<=i;j++){
        SelectDisease.setItems(observableList);
//        SelectDisease.setSelectionModel(value);
//String value = (String) SelectDisease.getSelectionModel().select(1);

//        System.out.println(value);
//SelectDisease.setOnAction(value);

        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select disease_id From diseases Where disease_name= 'Cardiology'";
            
            ResultSet rs=stmt.executeQuery(sqlquery);
            while(rs.next())
            {
                dis_id=rs.getInt("disease_id");
                
            }
//            rs.close();
//            stmt.close();
//            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        ComboBox SelectDoctor = new ComboBox();
List<String> listdoc = new ArrayList<String>();
ObservableList<String> observableListdoc = FXCollections.observableList(listdoc);

SelectDisease.valueProperty().addListener((obs, oldValue, newValue) -> {
//    if (newValue == null) {
//        SelectDoctor.getItems().clear();
//        SelectDoctor.setDisable(true);
//    } 
//    else {
        // sample code, adapt as needed:
//        List<listdoc> states = SelectDoctor.(newValue);
//        cbxState.getItems().setAll(SelectDoctor).listdoc.add(rs.getString("doctor_name").toString());
//        cbxState.setDisable(false);
try{
    System.out.println("In combo box Changing doctor");
            Class.forName("oracle.jdbc.driver.OracleDriver");
                    System.out.println("Here 1st");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
                    System.out.println("Here 2");
            Statement stmt=con.createStatement();
            //System.out.println("PID = "+Integer.parseInt(DidAppointment.getText()));              
            System.out.println("Added row to Doctorss table");  
//            Patients p=new Patients(Integer.parseInt(DidAppointment.getText()), Dname.getText(), Integer.parseInt(Dcont.getText()), Daddress.getText(), Integer.parseInt(Page.getText()));
//            String sql=("Insert Into Patients (patient_id,patient_name,phone,Daddress,patient_age) Values("+patient_id+",'"+patient_name+"',"+phone+",'"+patient_address+"',"+patient_age+")");     
                    
            String sql="SELECT doctor_name FROM doctorss ,diseases  where speciality=disease_id and speciality=(Select disease_id From Diseases Where disease_name='"+SelectDisease.getSelectionModel().getSelectedItem().toString()+"')";     
                           System.out.println("Selected");  
            ResultSet rs=stmt.executeQuery(sql);
//                    System.out.println("Exe here");
            while(rs.next()){
//                System.out.println(k);
//                String doc=new String[];
System.out.println("In Resultset of getting doctors");             
//String[] dname=new String[100];
//dname[0]=r/s.getString("doctor_name");
listdoc.add(rs.getString("doctor_name"));
//             SelectDisease.getItem().add(dis);
//            ++k;
            }
//                stmt.executeQuery(sql);
        stmt.close();
        con.close();
            }
            catch(Exception exce){
                System.out.println("in Exception of combo box");
            System.out.println(exce.getMessage());
        }
     
//    for(int j=0;j<=i;j++){
//listdoc.add("hres");
        SelectDoctor.setItems(observableListdoc);
        SelectDisease.setVisible(true);
//    }
});
//int k=0;
//Retrieving Diseases.;
//                try{
//    
//            Class.forName("oracle.jdbc.driver.OracleDriver");
//                    System.out.println("Here 1st");
//            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
//                    System.out.println("Here 2");
//            Statement stmt=con.createStatement();
//            //System.out.println("PID = "+Integer.parseInt(DidAppointment.getText()));              
//            System.out.println("Added row to customers table");  
////            Patients p=new Patients(Integer.parseInt(DidAppointment.getText()), Dname.getText(), Integer.parseInt(Dcont.getText()), Daddress.getText(), Integer.parseInt(Page.getText()));
////            String sql=("Insert Into Patients (patient_id,patient_name,phone,Daddress,patient_age) Values("+patient_id+",'"+patient_name+"',"+phone+",'"+patient_address+"',"+patient_age+")");     
//                    
//            String sql="SELECT doctor_name FROM doctorss ,diseases  where speciality=disease_id and speciality=(Select disease_id From Diseases Where disease_name='Surgery')";     
//                           System.out.println("Selected");  
//            ResultSet rs=stmt.executeQuery(sql);
//                    System.out.println("Exe here");
//            while(rs.next()){
//                System.out.println(k);
////                String doc=new String[];
//             listdoc.add(rs.getString("doctor_name").toString());
////             SelectDisease.getItem().add(dis);
////            ++k;
//            }
//                stmt.executeQuery(sql);
//        stmt.close();
//        con.close();
//            }
//            catch(Exception exce){
//                System.out.println("in Exception");
//            System.out.println(exce.getMessage());
//        }
//     ObservableList<String> observableListdoc = FXCollections.observableList(listdoc);
////    for(int j=0;j<=i;j++){
        SelectDoctor.setItems(observableListdoc);
    grid.add(MStauts,2,3);
    grid.add(address,2,6);
    grid.add(SelectDoctor,2,12);
    grid.add(SelectDisease,2,9);
     
//    String value = (String) comboBox.getValue();

 Button submit = new Button("Submit");
    //Submit.setPrefSize(100, 20);
    grid.add(submit,1,16);
    
    Label lblResponse = new Label();
    grid.add(lblResponse, 1, 18);
    
DropShadow shadow = new DropShadow();
        submit.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
            submit.setEffect(shadow); });
        
        //clear.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
        //    clear.setEffect(shadow); });
     
        submit.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
            submit.setEffect(null);});
        
        //clear.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
        //    clear.setEffect(null);});
// String c1,c2,c3,c4,c5,c6;       
        submit.setOnAction((ActionEvent e)->{
            System.out.println("About to Connection");
//        System.out.println(index_Dis_id);
            
            try{
    
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement st=con.createStatement();
            
            String sql2="Insert Into Patientss( patient_id, patient_name, patient_phone , patient_address , patient_age , disease) VALUES("+patientid+",'"+Pname.getText().toString()+"',"+Integer.parseInt(Pcont.getText())+",'"+address.getText().toString()+"',"+Integer.parseInt(Page.getText())+","+dis_id+")"+" ";
              
st.executeUpdate(sql2);                    
            System.out.println("inserted");
            
            
            st.close();
            con.close();
            }
            catch(Exception exce){
                System.out.println("in Exception");
            System.out.println(exce.getMessage());
        }
        
//            if(Dname.getText()!=null && !Dname.getText().isEmpty())
//            {
//                lblResponseDoc.setText(Dname.getText() + " "+
//                        "Patient Added");
//                
//            }
//            else
//            {
//                lblResponseDoc.setText("Patient Name Not Added");
//            }
        });
/******************************************************************************/     
/******************************************************************************/
        //Adding Doctor Grid
        GridPane docgrid = new GridPane();
        docgrid.setHgap(10);
        docgrid.setVgap(5);
        docgrid.setPadding(new Insets(0, 10, 0, 10));
    docgrid.setVisible(true);
//    docgrid.setGridLinesVisible(true);
    
// Category in column 2, row 1
    Text operationsdoc = new Text("Operations:");
    operationsdoc.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    docgrid.add(operationsdoc, 1, 0); 

    // Title in column 3, row 1
    Text chartTitledoc = new Text("Doctor Registration");   
    chartTitledoc.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    docgrid.add(chartTitledoc, 2, 0);

    
    /*ImageView imageHouse = new ImageView(
       new Image(LayoutExample.class.getResourceAsStream("home.gif")));
    docgrid.add(imageHouse, 0, 0, 1, 2); 
*/
    
    
    //Labels
    Label dID = new Label("Doctor ID");
    Label dName = new Label("Doctor Name");
    Label dCont = new Label("Contact No");
//    Label pAge = new Label("Doctor Age");
    docgrid.add(dID,0,2);
    docgrid.add(dName,0,5);
    docgrid.add(dCont,0,8);
//    docgrid.add(pAge,0,11);
    
//    Label pMaritalstatus = new Label("Marital Status");
    Label dAddress = new Label("Doctor Address");
    Label Specialization = new Label("Specialization");
//    Label Doctor = new Label("Select Doctor");
    
    
//    docgrid.add(pMaritalstatus,2,2);
    docgrid.add(dAddress,2,5);
    docgrid.add(Specialization,2,8);
    docgrid.add(Doctor,2,11);
//TextField 
    TextField Did = new TextField("");
    TextField Dname = new TextField("");
    TextField Dcont = new TextField("");
//    TextField Page = new TextField("");
    docgrid.add(Did,0,3);
    docgrid.add(Dname,0,6);
    docgrid.add(Dcont,0,9);
//    docgrid.add(Page,0,12);
    
//    ComboBox MStauts = new ComboBox();
//    MStauts.getItems().addAll(
//            "Sigle",
//            "Married" 
//        );
        
    TextField Daddress=new TextField("");
    
    
        
//    ComboBox SelectDisease = new ComboBox();
//    //SelectDisease.;
//    SelectDisease.getItems().addAll(
//            "A",
//            "B",
//            "C",
//            "D"
//        );
//    ComboBox SelectDoctor = new ComboBox();
//    SelectDoctor.getItems().addAll(
//            "A",
//            "B",
//            "C",
//            "D"
//        );
//    docgrid.add(MStauts,2,3);
    docgrid.add(Daddress,2,6);
//    docgrid.add(SelectDoctor,2,12);
//    docgrid.add(SelectDisease,2,9);
     
      
   // TextArea Daddress=new TextArea("");
   //address.setEditable(true);
    //address.setS
   // docgrid.add(Daddress,2,6,4,1);
 Button submitDoc = new Button("Submit");
    //Submit.setPrefSize(100, 20);
    docgrid.add(submitDoc,1,16);
    
    Label lblResponseDoc = new Label();
    docgrid.add(lblResponseDoc, 1, 18);
    
//DropShadow shadow = new DropShadow();
        submitDoc.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
            submitDoc.setEffect(shadow); });
        
        //clear.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
        //    clear.setEffect(shadow); });
        
        submitDoc.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
            submitDoc.setEffect(null);});
        
        //clear.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
        //    clear.setEffect(null);});
        
        submitDoc.setOnAction((ActionEvent e)->{
            System.out.println("About to Connect");
            try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Insert INTO Doctors(doctor_id,doctor_name,phone,address,doctor_age) VALUES("+(Integer.parseInt(Did.getText()))+",'"+Dname.getText()+"','"+Integer.parseInt(Dcont.getText())+"','"+Daddress.getText()+"','"+Integer.parseInt(Page.getText())+"')";  
//"VALUES(1,'EHTESHAM',09238498,'SUKKUR HMC',23);" +
//" VALUES("+DidAppointment.getText()+",'"+Dname.getText()+"',"+Page.getText()+","+dCont+",'"+MStauts.getValue()+"','"+Daddress.getText()+"','"+SelectDisease.getValue()+"','"+SelectDoctor.getValue()+"');\n" +
//" ";
stmt.executeUpdate(sqlquery);
          System.out.println("Added row to Doctors table");  
//            ResultSet rs=stmt.executeUpdate(sqlquery);
//            
//            while(rs.next())
//            {
//                System.out.println(rs.getString("first_name"));   
//            }
        stmt.close();
        con.close();
        }
            catch(Exception exce){
            System.out.println(exce.getMessage());
        }
//            if(Dname.getText()!=null && !Dname.getText().isEmpty())
//            {
//                lblResponseDoc.setText(Dname.getText() + " "+
//                        "Patient Added");
//                
//            }
//            else
//            {
//                lblResponseDoc.setText("Patient Name Not Added");
//            }
        });
 /******************************************************************************/       
    //Appointment Grid
    GridPane gridAppointment = new GridPane();
    gridAppointment.setHgap(15);
    gridAppointment.setVgap(15);
    gridAppointment.setPadding(new Insets(0, 10, 0, 10));
    
//    gridAppointment.setGridLinesVisible(true);
    
// Category in column 2, row 1
    Text operationsAppointment = new Text("Operations:");
    operationsAppointment.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    gridAppointment.add(operationsAppointment, 2, 3); 

    // Title in column 3, row 1
    Text chartTitleAppointment = new Text(" Book an Appointment ");   
    chartTitleAppointment.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    gridAppointment.add(chartTitleAppointment, 3, 3);

    Label PidAppointment = new Label("Select Patient");
    Label DidAppointment = new Label("Select Doctor");
    gridAppointment.add(PidAppointment,2,5);
    gridAppointment.add(DidAppointment,2,8);
    
//      TextField pid = new TextField("");
//      TextField did = new TextField("");
//      gridAppointment.add(pid,3,5);
//      gridAppointment.add(did,3,8);
      
      ComboBox Patients = new ComboBox();
      String patientName;
//    ComboBox SelectDisease = new ComboBox();
List<String> listAppointment = new ArrayList<String>();

int l=0;
//Retrieving Diseases.;
                try{
    
            Class.forName("oracle.jdbc.driver.OracleDriver");
                    System.out.println("Here 1st");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
                    System.out.println("Here 2");
            Statement stmt=con.createStatement();
            //System.out.println("PID = "+Integer.parseInt(PidAppointment.getText()));              
            System.out.println("Added row to customers table");  
//            Patients p=new Patients(Integer.parseInt(PidAppointment.getText()), Pname.getText(), Integer.parseInt(Pcont.getText()), address.getText(), Integer.parseInt(Page.getText()));
//            String sql=("Insert Into Patients (patient_id,patient_name,phone,address,patient_age) Values("+patient_id+",'"+patient_name+"',"+phone+",'"+patient_address+"',"+patient_age+")");     
                    
            String sql="Select Patient_name From Patientss";     
                           System.out.println("Selected");  
            ResultSet rs=stmt.executeQuery(sql);
                           System.out.println("Exception Here");  
            while(rs.next()){
                listAppointment.add(rs.getString("patient_name").toString());
//        String val=rs.getString("Disease_name").toString();
//Dis
//             SelectDisease.getItem().add(dis);
//            ++i;
            }
//                stmt.executeQuery(sql);
        stmt.close();
        con.close();
            }
            catch(Exception exce){
                System.out.println("in Exception");
            System.out.println(exce.getMessage());
        }
     ObservableList<String> observableListAppointment = FXCollections.observableList(listAppointment);
//    for(int j=0;j<=i;j++){
        Patients.setItems(observableListAppointment);
        gridAppointment.add(Patients,3,5);
//    gridAppointment.add(PidAppointment,2,5);
    
    
        ComboBox Doctors = new ComboBox();
        List<String> listdocAppointment = new ArrayList<String>();
        try{
    
            Class.forName("oracle.jdbc.driver.OracleDriver");
                    System.out.println("Here 1st");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
                    System.out.println("Here 2");
            Statement stmt=con.createStatement();
            System.out.println("Added row to customers table");  
            String sql="SELECT doctor_name FROM doctorss ,diseases  where speciality=disease_id and speciality=(Select disease_id From Diseases Where disease_name='Surgery')";     
                           System.out.println("Selected");  
            ResultSet rs=stmt.executeQuery(sql);
                    System.out.println("Exe here");
            while(rs.next()){
//                System.out.println(k);
//                String doc=new String[];
             listdocAppointment.add(rs.getString("doctor_name").toString());
//             SelectDisease.getItem().add(dis);
//            ++k;
            }
                stmt.executeQuery(sql);
        stmt.close();
        con.close();
            }
            catch(Exception exce){
                System.out.println("in Exception");
            System.out.println(exce.getMessage());
        }
     ObservableList<String> observableListdocApp = FXCollections.observableList(listdocAppointment);

        Doctors.setItems(observableListdocApp); 
        gridAppointment.add(Doctors,3,8);
//        gridAppointment.add(DidAppointment,2,8);
 Button submitAppointment = new Button("Submit");
    submitAppointment.setPrefSize(100, 20);
    gridAppointment.add(submitAppointment,3,11);
    
    Label lblResponseAppointment = new Label();
   gridAppointment.add(lblResponseAppointment, 2, 14);
    
DropShadow shadowApp = new DropShadow();
        submitAppointment.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
            submitAppointment.setEffect(shadow); });
        
        //clear.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
        //    clear.setEffect(shadow); });
        
        submitAppointment.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
            submitAppointment.setEffect(null);});
        
        //clear.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
        //    clear.setEffect(null);});
        
        submitAppointment.setOnAction((ActionEvent e)->{
            System.out.println("About to Connection");
//            try{
//            Class.forName("oracle.jdbc.driver.OracleDriver");
//            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
//            Statement stmt=con.createStatement(); 
//            String SqlPatId="SELECT patient_id FROM patients Where patient_name = Ehtesham";
//            System.out.println("Added row to customers table");  
//                stmt.executeUpdate(SqlPatId);
//                int rs=stmt.executeUpdate(SqlPatId);
//                System.out.println("Patient ID = "+rs);
//            String SqlDidId="SELECT d_id FROM doctors Where d_name="+Dname;
//                int Doctor_ID=stmt.executeUpdate(SqlDidId);
//               Date dob = java.sql.Date.valueOf("1969-02-22");
               
//               Date dob=java.sql.Date(Calender.getInstance());
//            String sqlapp="Insert Into appointments(patient_id_fk,doctor_id_fk,apointment_date) VALUES("+Patient_ID+","+Doctor_ID+","+dob+")";
//               stmt.executeUpdate(sqlapp);
//            while(rs.next())
//            {
//                System.out.println(rs.getString("first_name"));   
//            }
        
            
//            catch(Exception exce){
//            System.out.println(exce.getMessage());
//        }
//            if(Pname.getText()!=null && !Pname.getText().isEmpty())
//            {
//                lblResponseAppointment.setText(Pname.getText() + " "+
//                        "Patient Added");
//                
//            }
//            else
//            {
                lblResponseAppointment.setText("Your Have Appointment At 06:00 PM");
                lblResponseAppointment.setVisible(true);
            
   
            
        });


        BorderPane root = new BorderPane();
        
        root.setTop(addHBox());
        root.setLeft(addVBox());
//        root.setCenter(addGridPane());
        root.setCenter(grid);
        root.setBottom(addFooter());
options[0].setOnAction((ActionEvent e)->{
//        docgrid.add
        root.setCenter(grid);
//        docgrid.setVisible(true);
        });

        options[1].setOnAction((ActionEvent e)->{
//        docgrid.add
        root.setCenter(docgrid);
//        docgrid.setVisible(true);
        });
        options[2].setOnAction((ActionEvent e)->{
//        docgrid.add
        root.setCenter(gridAppointment);
//        docgrid.setVisible(true);
        });
        options[3].setOnAction((ActionEvent e)->{
//        docgrid.add
        root.setCenter(DoctorsData());
//        docgrid.setVisible(true);
        });
        options[4].setOnAction((ActionEvent e)->{
//        docgrid.add
        root.setCenter(PatientsData());
//        docgrid.setVisible(true);
        });
        options[5].setOnAction((ActionEvent e)->{
//        docgrid.add
        root.setCenter(addGridPaneReportGenerate());
//        docgrid.setVisible(true);
        });
        options[6].setOnAction((ActionEvent e)->{
//        docgrid.add
        root.setCenter(ReportsData());
//        docgrid.setVisible(true);
        });
        
        
        
        Scene scene = new Scene(root, 720, 480);
        scene.getStylesheets().add("patient_reg_connect_ret_pat_doc/controlStyles.css");
//        scene.getStylesheets().add("insetusingconnectino/controlStyles.css");
        
        primaryStage.setTitle("Hospital Managment System");
        primaryStage.setScene(scene);
        primaryStage.show();
        //Patients p=new Patients(Integer.parseInt(DidAppointment.getText()), Dname.getText(), Integer.parseInt(Dcont.getText()), Daddress.getText(), Integer.parseInt(Page.getText()));
        
    }
    
    public HBox addHBox() {
        
    HBox hbox = new HBox();
    hbox.setPadding(new Insets(15, 12, 15, 12));
    hbox.setSpacing(10);
    hbox.setStyle("-fx-background-color: #336699;");
    
    //Adding The LAbel in Top HBOX
    //Label patRegFrom = new Label("Patient Registration Form");
    //patRegFrom.setPrefSize(150, 30);
    //patRegFrom.setFont(Font.font("Arial", FontWeight.BOLD, 20));
   //Add a title to the page
        Text title = new Text("Patient Registration Form");
        //title.setFill(Paint.valueOf("#2A5058"));
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
// Button buttonCurrent = new Button("Home");
    //buttonCurrent.setPrefSize(100, 20);

    //Button buttonProjected = new Button("Exit");
    //buttonProjected.setPrefSize(100, 20);
    
    hbox.getChildren().addAll(title);  //buttonCurrent, buttonProjected,

    return hbox;
}
    
//Method Returning Horizental Box

    public HBox addFooter(){
        HBox hbox = new HBox();
        hbox.setPadding(new Insets(15, 12, 15, 12));
        hbox.setSpacing(10);
        hbox.setStyle("-fx-background-color: #336699");
        Text copyright = new Text("Hospital Managment System ");
        copyright.setFill(Color.WHITE);
        copyright.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        hbox.getChildren().add(copyright);
        return hbox;
    }
    
    public VBox addVBox() {
    VBox vbox = new VBox();
    vbox.setPadding(new Insets(10));
    vbox.setSpacing(8);

    Text title = new Text("Operations");
    title.setFont(Font.font("Arial", FontWeight.BOLD, 14));
    vbox.getChildren().add(title);
    for (int i=0; i<7; i++) {
        VBox.setMargin(options[i], new Insets(0, 0, 0, 8));
        vbox.getChildren().add(options[i]);
    }
    return vbox;
}
    
    public GridPane addGridPane() {

/******************************************************************************/
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(5);
        grid.setPadding(new Insets(0, 10, 0, 10));
        grid.setVisible(false);
    
//    docgrid.setGridLinesVisible(true);
    
// Category in column 2, row 1
    Text operations = new Text("Operations:");
    operations.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    grid.add(operations, 1, 0); 

    // Title in column 3, row 1
    Text chartTitle = new Text("Patient Registration");   
    chartTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    grid.add(chartTitle, 2, 0);

    
    /*ImageView imageHouse = new ImageView(
       new Image(LayoutExample.class.getResourceAsStream("home.gif")));
    docgrid.add(imageHouse, 0, 0, 1, 2); 
*/
    
    
    //Labels
    Label pID = new Label("Patient ID");
    Label pName = new Label("Patient Name");
    Label pCont = new Label("Contact No");
    Label pAge = new Label("Patient Age");
    grid.add(pID,0,2);
    grid.add(pName,0,5);
    grid.add(pCont,0,8);
    grid.add(pAge,0,11);
    
    Label pMaritalstatus = new Label("Gender");
    Label pAddress = new Label("Patient Address");
    Label Disease = new Label("Select Disease");
    Label Doctor = new Label("Select Doctor");
    
    
    grid.add(pMaritalstatus,2,2);
    grid.add(pAddress,2,5);
    grid.add(Disease,2,8);
    grid.add(Doctor,2,11);
//TextField 
//String Patid=Integer.toString(++patientid);
try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select Patient_id from Patientss";
            ResultSet rs=stmt.executeQuery(sqlquery);
//             stmt.close();
             while(rs.next())
             {
                 patientid=rs.getInt("Patient_id");
                 System.out.println(patientid);
             }
             ++patientid;
             System.out.println("Out"+patientid);
//            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
System.out.println(" Saffa Out"+patientid);
//String Patid=Integer.toString(patientid);
    TextField Pid = new TextField("");
    Pid.setText(Integer.toString(patientid));
    Pid.setEditable(false);
    TextField Pname = new TextField("");
    TextField Pcont = new TextField("");
    TextField Page = new TextField("");
    grid.add(Pid,0,3);
    grid.add(Pname,0,6);
    grid.add(Pcont,0,9);
    grid.add(Page,0,12);
    
    ComboBox MStauts = new ComboBox();
    MStauts.getItems().addAll(
            "Sigle",
            "Married" 
        );
    
//    int index=1;
        MStauts.getSelectionModel().selectedItemProperty();
        String ms=MStauts.getSelectionModel().getSelectedItem().toString();
        
//        System.out.println("ms");
//        MStauts.Selecte
    TextField address=new TextField("");
    
    
        
    ComboBox SelectDisease = new ComboBox();
List<String> list = new ArrayList<String>();

int i=0;
//Retrieving Diseases.;
                try{
    
            Class.forName("oracle.jdbc.driver.OracleDriver");
                    System.out.println("Here 1st");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
                    System.out.println("Here 2");
            Statement stmt=con.createStatement();
            //System.out.println("PID = "+Integer.parseInt(DidAppointment.getText()));              
            System.out.println("Added row to customers table");  
//            Patients p=new Patients(Integer.parseInt(DidAppointment.getText()), Dname.getText(), Integer.parseInt(Dcont.getText()), Daddress.getText(), Integer.parseInt(Page.getText()));
//            String sql=("Insert Into Patients (patient_id,patient_name,phone,Daddress,patient_age) Values("+patient_id+",'"+patient_name+"',"+phone+",'"+patient_address+"',"+patient_age+")");     
                    
            String sql="Select Disease_name From diseases";     
                           System.out.println("Selected");  
            ResultSet rs=stmt.executeQuery(sql);
                           System.out.println("Exception Here");  
            while(rs.next()){
                list.add(rs.getString("disease_name").toString());
//        String val=rs.getString("Disease_name").toString();
//Dis
//             SelectDisease.getItem().add(dis);
            ++i;
            }
                stmt.executeQuery(sql);
        stmt.close();
        con.close();
            }
            catch(Exception exce){
                System.out.println("in Exception");
            System.out.println(exce.getMessage());
        }
     ObservableList<String> observableList = FXCollections.observableList(list);
//    for(int j=0;j<=i;j++){
        SelectDisease.setItems(observableList);
//        SelectDisease.setSelectionModel(value);
//String value = (String) SelectDisease.getSelectionModel().select(1);

//        System.out.println(value);
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select disease_id From diseases Where disease_name= 'Cardiology'";
            
            ResultSet rs=stmt.executeQuery(sqlquery);
            while(rs.next())
            {
                dis_id=rs.getInt("disease_id");
                
            }
//            rs.close();
//            stmt.close();
//            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        ComboBox SelectDoctor = new ComboBox();
List<String> listdoc = new ArrayList<String>();

int k=0;
//Retrieving Diseases.;
                try{
    
            Class.forName("oracle.jdbc.driver.OracleDriver");
                    System.out.println("Here 1st");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
                    System.out.println("Here 2");
            Statement stmt=con.createStatement();
            //System.out.println("PID = "+Integer.parseInt(DidAppointment.getText()));              
            System.out.println("Added row to customers table");  
//            Patients p=new Patients(Integer.parseInt(DidAppointment.getText()), Dname.getText(), Integer.parseInt(Dcont.getText()), Daddress.getText(), Integer.parseInt(Page.getText()));
//            String sql=("Insert Into Patients (patient_id,patient_name,phone,Daddress,patient_age) Values("+patient_id+",'"+patient_name+"',"+phone+",'"+patient_address+"',"+patient_age+")");     
                    
            String sql="SELECT doctor_name FROM doctorss ,diseases  where speciality=disease_id and speciality=(Select disease_id From Diseases Where disease_name='jhkkjh')";     
                           System.out.println("Selected");  
            ResultSet rs=stmt.executeQuery(sql);
                    System.out.println("Exe here");
            while(rs.next()){
                System.out.println(k);
//                System.out.println(ms);
//                String doc=new String[];
             listdoc.add(rs.getString("doctor_name").toString());
//             SelectDisease.getItem().add(dis);
//            ++k;
            }
                stmt.executeQuery(sql);
        stmt.close();
        con.close();
            }
            catch(Exception exce){
                System.out.println("in Exception");
            System.out.println(exce.getMessage());
        }
     ObservableList<String> observableListdoc = FXCollections.observableList(listdoc);
//    for(int j=0;j<=i;j++){
        SelectDoctor.setItems(observableListdoc);
    grid.add(MStauts,2,3);
    grid.add(address,2,6);
    grid.add(SelectDoctor,2,12);
    grid.add(SelectDisease,2,9);
     
//    String value = (String) comboBox.getValue();

 Button submit = new Button("Submit");
    //Submit.setPrefSize(100, 20);
    grid.add(submit,1,16);
    
    Label lblResponse = new Label();
    grid.add(lblResponse, 1, 18);
    
DropShadow shadow = new DropShadow();
        submit.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
            submit.setEffect(shadow); });
        
        //clear.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
        //    clear.setEffect(shadow); });
     
        submit.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
            submit.setEffect(null);});
        
        //clear.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
        //    clear.setEffect(null);});
// String c1,c2,c3,c4,c5,c6;       
        submit.setOnAction((ActionEvent e)->{
            System.out.println("About to Connection");
//        System.out.println(index_Dis_id);
            
            try{
    
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement st=con.createStatement();
            
            String sql2="Insert Into Patientss( patient_id, patient_name, patient_phone , patient_address , patient_age , disease) VALUES("+patientid+",'"+Pname.getText().toString()+"',"+Integer.parseInt(Pcont.getText())+",'"+address.getText().toString()+"',"+Integer.parseInt(Page.getText())+","+dis_id+")"+" ";
              
st.executeUpdate(sql2);                    
            System.out.println("inserted");
            
            
            st.close();
            con.close();
            }
            catch(Exception exce){
                System.out.println("in Exception");
            System.out.println(exce.getMessage());
        }
        
//            if(Dname.getText()!=null && !Dname.getText().isEmpty())
//            {
//                lblResponseDoc.setText(Dname.getText() + " "+
//                        "Patient Added");
//                
//            }
//            else
//            {
//                lblResponseDoc.setText("Patient Name Not Added");
//            }
        });
/******************************************************************************/
        //Adding Doctor Grid
        GridPane docgrid = new GridPane();
        docgrid.setHgap(10);
        docgrid.setVgap(5);
        docgrid.setPadding(new Insets(0, 10, 0, 10));
    docgrid.setVisible(false);
//    docgrid.setGridLinesVisible(true);
    
// Category in column 2, row 1
    Text operationsdoc = new Text("Operations:");
    operationsdoc.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    docgrid.add(operationsdoc, 1, 0); 

    // Title in column 3, row 1
    Text chartTitledoc = new Text("Doctor Registration");   
    chartTitledoc.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    docgrid.add(chartTitledoc, 2, 0);

    
    /*ImageView imageHouse = new ImageView(
       new Image(LayoutExample.class.getResourceAsStream("home.gif")));
    docgrid.add(imageHouse, 0, 0, 1, 2); 
*/
    
    
    //Labels
    Label dID = new Label("Doctor ID");
    Label dName = new Label("Doctor Name");
    Label dCont = new Label("Contact No");
//    Label pAge = new Label("Doctor Age");
    docgrid.add(dID,0,2);
    docgrid.add(dName,0,5);
    docgrid.add(dCont,0,8);
//    docgrid.add(pAge,0,11);
    
//    Label pMaritalstatus = new Label("Marital Status");
    Label dAddress = new Label("Doctor Address");
    Label Specialization = new Label("Specialization");
//    Label Doctor = new Label("Select Doctor");
    
    
//    docgrid.add(pMaritalstatus,2,2);
    docgrid.add(dAddress,2,5);
    docgrid.add(Specialization,2,8);
    docgrid.add(Doctor,2,11);
//TextField 
    TextField Did = new TextField("");
    TextField Dname = new TextField("");
    TextField Dcont = new TextField("");
//    TextField Page = new TextField("");
    docgrid.add(Did,0,3);
    docgrid.add(Dname,0,6);
    docgrid.add(Dcont,0,9);
//    docgrid.add(Page,0,12);
    
//    ComboBox MStauts = new ComboBox();
//    MStauts.getItems().addAll(
//            "Sigle",
//            "Married" 
//        );
        
    TextField Daddress=new TextField("");
    
    
        
//    ComboBox SelectDisease = new ComboBox();
//    //SelectDisease.;
//    SelectDisease.getItems().addAll(
//            "A",
//            "B",
//            "C",
//            "D"
//        );
//    ComboBox SelectDoctor = new ComboBox();
//    SelectDoctor.getItems().addAll(
//            "A",
//            "B",
//            "C",
//            "D"
//        );
//    docgrid.add(MStauts,2,3);
    docgrid.add(Daddress,2,6);
//    docgrid.add(SelectDoctor,2,12);
//    docgrid.add(SelectDisease,2,9);
     
      
   // TextArea Daddress=new TextArea("");
   //address.setEditable(true);
    //address.setS
   // docgrid.add(Daddress,2,6,4,1);
 Button submitDoc = new Button("Submit");
    //Submit.setPrefSize(100, 20);
    docgrid.add(submitDoc,1,16);
    
    Label lblResponseDoc = new Label();
    docgrid.add(lblResponseDoc, 1, 18);
    
//DropShadow shadow = new DropShadow();
        submitDoc.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
            submitDoc.setEffect(shadow); });
        
        //clear.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
        //    clear.setEffect(shadow); });
        
        submitDoc.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
            submitDoc.setEffect(null);});
        
        //clear.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
        //    clear.setEffect(null);});
        
        submitDoc.setOnAction((ActionEvent e)->{
            System.out.println("About to Connect");
            try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Insert INTO Doctors(doctor_id,doctor_name,phone,address,doctor_age) VALUES("+(Integer.parseInt(Did.getText()))+",'"+Dname.getText()+"','"+Integer.parseInt(Dcont.getText())+"','"+Daddress.getText()+"','"+Integer.parseInt(Page.getText())+"')";  
//"VALUES(1,'EHTESHAM',09238498,'SUKKUR HMC',23);" +
//" VALUES("+DidAppointment.getText()+",'"+Dname.getText()+"',"+Page.getText()+","+dCont+",'"+MStauts.getValue()+"','"+Daddress.getText()+"','"+SelectDisease.getValue()+"','"+SelectDoctor.getValue()+"');\n" +
//" ";
stmt.executeUpdate(sqlquery);
          System.out.println("Added row to Doctors table");  
//            ResultSet rs=stmt.executeUpdate(sqlquery);
//            
//            while(rs.next())
//            {
//                System.out.println(rs.getString("first_name"));   
//            }
        stmt.close();
        con.close();
        }
            catch(Exception exce){
            System.out.println(exce.getMessage());
        }
//            if(Dname.getText()!=null && !Dname.getText().isEmpty())
//            {
//                lblResponseDoc.setText(Dname.getText() + " "+
//                        "Patient Added");
//                
//            }
//            else
//            {
//                lblResponseDoc.setText("Patient Name Not Added");
//            }
        });
 /******************************************************************************/       
        
        /******************************************************************************/
                
/******************************************************************************/
    return grid;
}
    public TableView DoctorsData()
    {
         String c1="";
         String c2="";
         String c3="";
         String c4="";
            ObservableList<Doctorss> DoctorDataInList = FXCollections.observableArrayList();
        
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select doctor_id,doctor_name,doctor_phone,Doctor_address from Doctorss";
            
            ResultSet rs=stmt.executeQuery(sqlquery);
        //Fetching Column Names From Database Using Funcitons    
        c1=rs.getMetaData().getColumnName(1);//"Patient_id"
        c2=rs.getMetaData().getColumnName(2);//"Patient_name"
        c3=rs.getMetaData().getColumnName(3);//"phone"
        c4=rs.getMetaData().getColumnName(4);//"address"
//        c5=rs.getMetaData().getColumnName(5);//"Patient_age"
            while(rs.next())
            {
                Doctorss doc=new Doctorss((Integer.toString(rs.getInt(c1))), rs.getString(c2),rs.getString(c3),rs.getString(c4));
                DoctorDataInList.add(doc);
            }
//            rs.close();
//            stmt.close();
//            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
    TableView<Doctorss> TableViewDoctorData;
    //Adding above patients to Table view 
    
    //Asssociating colums with column Heading
    TableViewDoctorData = new TableView<>(DoctorDataInList);
    //Cell FActory to get cells populated with data
    TableColumn<Doctorss,String> col1= new TableColumn<>(c1);
    col1.setCellValueFactory(new PropertyValueFactory<>("Doctor_id"));
                                           //DataName of FirstColumn                    
    TableViewDoctorData.getColumns().add(col1);
    
    TableColumn<Doctorss,String> col2= new TableColumn<>(c2);
    col2.setCellValueFactory(new PropertyValueFactory<>("Doctor_name"));
                                           //DataName of FirstColumn                    
    TableViewDoctorData.getColumns().add(col2);
    TableColumn<Doctorss,String> col3= new TableColumn<>(c3);
    col3.setCellValueFactory(new PropertyValueFactory<>("Doctor_Phone"));
                                           //DataName of FirstColumn                    
    TableViewDoctorData.getColumns().add(col3);
    
    TableColumn<Doctorss,String> col4= new TableColumn<>(c4);
    col4.setCellValueFactory(new PropertyValueFactory<>("Doctor_address"));
                                           //DataName of FirstColumn                    
    TableViewDoctorData.getColumns().add(col4);
 
    //Setting Width and Height of  TableView
    TableViewDoctorData.setPrefWidth(350);
    TableViewDoctorData.setPrefHeight(350);
    
//    TableView.TableViewSelectionModel<Doctorss> TableViewSelectionPatientData=
//            TableViewDoctorData.getSelectionModel();
//    TableViewSelectionPatientData.selectedIndexProperty().addListener(new ChangeListener<Number>()
//    {
//        public void changed(ObservableValue<? extends Number> observable,
//                Number oldVal,Number newVal){
//            int index=(int)newVal;
//            response.setText("Age of Doctor you selected : "+DoctorDataInList.get(index).getDoctor_name());
//        }

              //@Override
              //public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
              //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
              //}
//    });   
            return TableViewDoctorData; 
}
    public TableView PatientsData()
    {
         String c1="";
         String c2="";
         String c3="";
         String c4="";
            ObservableList<Patientss> PatientDataInList = FXCollections.observableArrayList();
        
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select Patient_id,Patient_name,Patient_phone,Patient_address from Patientss";
            
            ResultSet rs=stmt.executeQuery(sqlquery);
        //Fetching Column Names From Database Using Funcitons    
        c1=rs.getMetaData().getColumnName(1);//"Patient_id"
        c2=rs.getMetaData().getColumnName(2);//"Patient_name"
        c3=rs.getMetaData().getColumnName(3);//"phone"
        c4=rs.getMetaData().getColumnName(4);//"address"
//        c5=rs.getMetaData().getColumnName(5);//"Patient_age"
            while(rs.next())
            {
                Patientss doc=new Patientss((Integer.toString(rs.getInt(c1))), rs.getString(c2),rs.getString(c3),rs.getString(c4));
                PatientDataInList.add(doc);
            }
//            rs.close();
//            stmt.close();
//            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
    TableView<Patientss> TableViewPatientData;
    //Adding above patients to Table view 
    
    //Asssociating colums with column Heading
    TableViewPatientData = new TableView<>(PatientDataInList);
    //Cell FActory to get cells populated with data
    TableColumn<Patientss,String> col1= new TableColumn<>(c1);
    col1.setCellValueFactory(new PropertyValueFactory<>("Patient_id"));
                                           //DataName of FirstColumn                    
    TableViewPatientData.getColumns().add(col1);
    
    TableColumn<Patientss,String> col2= new TableColumn<>(c2);
    col2.setCellValueFactory(new PropertyValueFactory<>("Patient_name"));
                                           //DataName of FirstColumn                    
    TableViewPatientData.getColumns().add(col2);
    TableColumn<Patientss,String> col3= new TableColumn<>(c3);
    col3.setCellValueFactory(new PropertyValueFactory<>("Patient_Phone"));
                                           //DataName of FirstColumn                    
    TableViewPatientData.getColumns().add(col3);
    
    TableColumn<Patientss,String> col4= new TableColumn<>(c4);
    col4.setCellValueFactory(new PropertyValueFactory<>("Patient_address"));
                                           //DataName of FirstColumn                    
    TableViewPatientData.getColumns().add(col4);
 
    //Setting Width and Height of  TableView
    TableViewPatientData.setPrefWidth(350);
    TableViewPatientData.setPrefHeight(350);
    
//    TableView.TableViewSelectionModel<Doctorss> TableViewSelectionPatientData=
//            TableViewDoctorData.getSelectionModel();
//    TableViewSelectionPatientData.selectedIndexProperty().addListener(new ChangeListener<Number>()
//    {
//        public void changed(ObservableValue<? extends Number> observable,
//                Number oldVal,Number newVal){
//            int index=(int)newVal;
//            response.setText("Age of Doctor you selected : "+DoctorDataInList.get(index).getDoctor_name());
//        }

              //@Override
              //public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
              //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
              //}
//    });   
            return TableViewPatientData; 
}
     public TableView ReportsData()
    {
         String c1="";
         String c2="";
         String c3="";
         String c4="";
            ObservableList<Reportss> ReportsInList = FXCollections.observableArrayList();
        
        try{
            System.out.println("In Reports Data");
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select Report_id,Report_Description,Patient_id,Doctor_id from Reports";
            
            ResultSet rs=stmt.executeQuery(sqlquery);
        //Fetching Column Names From Database Using Funcitons    
        c1=rs.getMetaData().getColumnName(1);//"Patient_id"
        c2=rs.getMetaData().getColumnName(2);//"Patient_name"
        c3=rs.getMetaData().getColumnName(3);//"phone"
        c4=rs.getMetaData().getColumnName(4);//"address"
//        c5=rs.getMetaData().getColumnName(5);//"Patient_age"
System.out.println("Entering in ResultSet");
            while(rs.next())
            {   System.out.println("Report 1 :"+Integer.toString(rs.getInt(c1))+rs.getString(c2)+Integer.toString(rs.getInt(c3))+Integer.toString(rs.getInt(c4))+"\n");
                Reportss rep=new Reportss((Integer.toString(rs.getInt(c1))), rs.getString(c2),Integer.toString(rs.getInt(c3)),Integer.toString(rs.getInt(c4)));
                ReportsInList.add(rep);
            }
//            rs.close();
//            stmt.close();
//            con.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
    TableView<Reportss> TableViewReports;
    //Adding above patients to Table view 
    
    //Asssociating colums with column Heading
    TableViewReports = new TableView<>(ReportsInList);
    //Cell FActory to get cells populated with data
    TableColumn<Reportss,String> col1= new TableColumn<>(c1);
    col1.setCellValueFactory(new PropertyValueFactory<>("Report_id"));
                                           //DataName of FirstColumn                    
    TableViewReports.getColumns().add(col1);
    
    TableColumn<Reportss,String> col2= new TableColumn<>(c2);
    col2.setCellValueFactory(new PropertyValueFactory<>("Report_description"));
                                           //DataName of FirstColumn                    
    TableViewReports.getColumns().add(col2);
    TableColumn<Reportss,String> col3= new TableColumn<>(c3);
    col3.setCellValueFactory(new PropertyValueFactory<>("Patient_id"));
                                           //DataName of FirstColumn                    
    TableViewReports.getColumns().add(col3);
    
    TableColumn<Reportss,String> col4= new TableColumn<>(c4);
    col4.setCellValueFactory(new PropertyValueFactory<>("Doctor_id"));
                                           //DataName of FirstColumn                    
    TableViewReports.getColumns().add(col4);
 
    //Setting Width and Height of  TableView
    TableViewReports.setPrefWidth(350);
    TableViewReports.setPrefHeight(350);
    
//    TableView.TableViewSelectionModel<Doctorss> TableViewSelectionPatientData=
//            TableViewDoctorData.getSelectionModel();
//    TableViewSelectionPatientData.selectedIndexProperty().addListener(new ChangeListener<Number>()
//    {
//        public void changed(ObservableValue<? extends Number> observable,
//                Number oldVal,Number newVal){
//            int index=(int)newVal;
//            response.setText("Age of Doctor you selected : "+DoctorDataInList.get(index).getDoctor_name());
//        }

              //@Override
              //public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
              //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
              //}
//    });   
            return TableViewReports; 
}

     public GridPane addGridPaneReportGenerate() {
    GridPane gridReport = new GridPane();
    gridReport.setHgap(10);
    gridReport.setVgap(10);
    gridReport.setPadding(new Insets(0, 10, 0, 10));
    
//    gridReport.setGridLinesVisible(true);
    
// Category in column 2, row 1
    Text operations = new Text("Operations:");
    operations.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    gridReport.add(operations, 2, 3); 

    // Title in column 3, row 1
    Text chartTitle = new Text(" Generate Patient Report ");   
    chartTitle.setFont(Font.font("Arial", FontWeight.BOLD, 20));
    gridReport.add(chartTitle, 3, 3);

    Label Pid = new Label("Select Patient");
    Label Did = new Label("Select Doctor");
    gridReport.add(Pid,2,5);
    gridReport.add(Did,2,7);
//    gridReport.setGridLinesVisible(true);
//      TextField pid = new TextField("");
//      TextField did = new TextField("");
//      gridReport.add(pid,3,5);
//      gridReport.add(did,3,8);
      
      ComboBox Patients = new ComboBox();
      
//      Patients.set
      try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select patient_name from Patientss";
            System.out.println("In patients Before Resultset");  
            ResultSet rs=stmt.executeQuery(sqlquery);
            
            while(rs.next())
            {
                System.out.println(rs.getString("patient_name"));   
        Patients.getItems().addAll(rs.getString("patient_name"));
    
            }
         stmt.close();
         rs.close();
         con.close();
        }
            catch(Exception exce){
            System.out.println(exce.getMessage());
        }
//    System.out.println("dof doctor try");    
    gridReport.add(Patients,3,5);
//Adding Combo box Doctors    
      ComboBox Doctors = new ComboBox();
      
//      Patients.set
      try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
            Statement stmt=con.createStatement();
            String sqlquery="Select doctor_name from Doctorss";
            System.out.println("In Doctorss Before Resultset");  
            ResultSet rs=stmt.executeQuery(sqlquery);
            
            while(rs.next())
            {
                System.out.println(rs.getString("Doctor_name"));   
        Doctors.getItems().addAll(rs.getString("Doctor_name"));
    
            }
         stmt.close();
         rs.close();
         con.close();
        }
            catch(Exception exce){
            System.out.println(exce.getMessage());
        }
//    System.out.println("dof doctor try");    
    gridReport.add(Doctors,3,7);
 Label rep=new Label("Write Report Below ");
 gridReport.add(rep,2,8);
    TextArea report=new TextArea("");
   report.setEditable(true);
//   report.
    //address.setS
    gridReport.add(report,2,10,5,4);
 Button submit = new Button("Submit");
    submit.setPrefSize(100, 20);
    gridReport.add(submit,3,14);
    
    Label lblResponse = new Label();
   gridReport.add(lblResponse, 4, 14);
    
DropShadow shadow = new DropShadow();
        submit.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
            submit.setEffect(shadow); });
        
        //clear.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
        //    clear.setEffect(shadow); });
        
        submit.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
            submit.setEffect(null);});
        
        //clear.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)-> {
        //    clear.setEffect(null);});
        
        submit.setOnAction((ActionEvent e)->{
            System.out.println("Button Pressed");
//            try{
//            Class.forName("oracle.jdbc.driver.OracleDriver");
//            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ehtesham");
//            Statement stmt=con.createStatement(); 
//            String SqlPatId="SELECT patient_id FROM patients Where patient_name = Ehtesham";
//            System.out.println("Added row to customers table");  
//                stmt.executeUpdate(SqlPatId);
//                int rs=stmt.executeUpdate(SqlPatId);
//                System.out.println("Patient ID = "+rs);
//            String SqlDidId="SELECT d_id FROM doctors Where d_name="+Dname;
//                int Doctor_ID=stmt.executeUpdate(SqlDidId);
//               Date dob = java.sql.Date.valueOf("1969-02-22");
               
//               Date dob=java.sql.Date(Calender.getInstance());
//            String sqlapp="Insert Into appointments(patient_id_fk,doctor_id_fk,apointment_date) VALUES("+Patient_ID+","+Doctor_ID+","+dob+")";
//               stmt.executeUpdate(sqlapp);
//            while(rs.next())
//            {
//                System.out.println(rs.getString("first_name"));   
//            }
        
            
//            catch(Exception exce){
//            System.out.println(exce.getMessage());
//        }
//            if(Pname.getText()!=null && !Pname.getText().isEmpty())
//            {
//                lblResponse.setText(Pname.getText() + " "+
//                        "Patient Added");
//                
//            }
//            else
//            {
                lblResponse.setText("Done**");
                lblResponse.setVisible(true);
            
   
            
        });
    return gridReport;
}
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        launch(args);
        
    }
    
}

