/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patient_reg_connect_ret_pat_doc;

/**
 *
 * @author ehtes
 */
public class Patientss {
private String Patient_id;    
private String Patient_name;    
private String Patient_phone;
private String Patient_address;    

    public Patientss(String Patient_id, String Patient_name, String Patient_phone, String Patient_address) {
        this.Patient_id = Patient_id;
        this.Patient_name = Patient_name;
        this.Patient_phone = Patient_phone;
        this.Patient_address = Patient_address;
    }

    public String getPatient_id() {
        return Patient_id;
    }

    public void setPatient_id(String Patient_id) {
        this.Patient_id = Patient_id;
    }

    public String getPatient_name() {
        return Patient_name;
    }

    public void setPatient_name(String Patient_name) {
        this.Patient_name = Patient_name;
    }

    public String getPatient_phone() {
        return Patient_phone;
    }

    public void setPatient_phone(String Patient_phone) {
        this.Patient_phone = Patient_phone;
    }

    public String getPatient_address() {
        return Patient_address;
    }

    public void setPatient_address(String Patient_address) {
        this.Patient_address = Patient_address;
    }

}
